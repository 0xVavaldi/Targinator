#include <iostream>
#include <fstream>
#include <string>
#include <cstring>
#include <cmath>
#include <vector>
#include <filesystem>


std::string delimiter;
std::vector<std::string> dictionary;


static void show_usage() {
    std::cerr << "Usage: PermutationFlagg [option(s)] > results.txt\n"
              << "Options:\n"
              << "\t-h,--help\t\t\tShow this help message\n"
              << "\t-w,--wordlist WORDLIST_FILE\tSpecify the input wordlist path\n"
              << "\t-d,--delimiter \" \"\tSpecify the delimiter for the words\n"
              << "\t--help\tShow this screen!\n"
              << "Version: 0.1\n"
              << "Author: Vavaldi [vavaldi@hashmob.net]\n\n"
              << std::endl;
}

std::vector<std::string> load_data(const std::string& input_file_location) {
    std::vector<std::string> output_dictionary;
    std::ifstream input_file(input_file_location);
    std::string line;
    while(getline(input_file, line)) {
        output_dictionary.push_back(std::move(line));
    }
    return output_dictionary;
}

// Join function to add delimiter
template <typename T>
std::string join(const T& v, const std::string& delim) {
    std::ostringstream s;
    for (const auto& i : v) {
        if (&i != &v[0]) {
            s << delim;
        }
        s << i;
    }
    return s.str();
}

// Loop through permutations recursively
void permute_all(std::vector<std::string>& buffer, size_t depth) {
    for(const auto& word : dictionary) {
        if (std::find(buffer.begin(), buffer.end(), word) != buffer.end()) continue;

        buffer.emplace_back(word);
        if(depth == 1) {
            std::cout << join(buffer, delimiter) << std::endl;
        } else {
            permute_all(buffer, depth - 1);
        }
        buffer.pop_back();
    }
}

int main(int argc, const char *argv[]) {
    if (argc < 2) {
        show_usage();
        return 1;
    }

    std::string input_wordlist;
    bool help{false};
    for (int i = 1; i < argc; ++i) {
        if (std::string(argv[i]) == "--wordlist" || std::string(argv[i]) == "-w") {
            if (i + 1 < argc && argv[i+1][0] != '-' && strlen(argv[i+1]) > 1 ) {
                input_wordlist = argv[i+1];
            } else {
                std::cerr << argv[i] << " option requires an argument." << std::endl;
                return -1;
            }
        }
        if (std::string(argv[i]) == "--delimiter" || std::string(argv[i]) == "-d") {
            if (i + 1 < argc && argv[i+1][0] != '-' && strlen(argv[i+1]) >= 1 ) {
                delimiter = argv[i+1];
            } else {
                std::cerr << argv[i] << " option requires an argument." << std::endl;
                return -1;
            }
        }
        if (std::string(argv[i]) == "--help" || std::string(argv[i]) == "-h") {
            help = true;
        }
    }

    if(help) {
        show_usage();
        return 0;
    }

    try {
        if (!std::filesystem::exists(input_wordlist)) {
            std::cerr << "Invalid Path" << std::endl;
            return 0;
        }
    } catch(...) {};

    dictionary = load_data(input_wordlist);
    std::vector<std::vector<std::string>> dictionary_power_set;
    std::vector<std::string> buffer;
    for(size_t length = 1; length <= dictionary.size(); length++) {
        permute_all(buffer, length);
    }

    return 0;
}

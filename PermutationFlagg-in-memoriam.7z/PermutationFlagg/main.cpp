#include <iostream>
#include <fstream>
#include <string>
#include <cstring>
#include <cmath>
#include <vector>
#include <filesystem>
#include <thread>
#include <queue>
#include <mutex>
#include <condition_variable>


std::string delimiter;
std::vector<std::string> dictionary;
std::vector<std::thread> threads;
std::mutex input_lock;
std::mutex output_lock;
std::queue<std::vector<std::vector<std::string>>> input_queue;
std::queue<std::vector<std::string>> output_queue;
std::condition_variable condition_var;
bool is_processing = true;
bool is_fully_done = false;


static void show_usage() {
    std::cerr << "Usage: PermutationFlagg [option(s)] > results.txt\n"
              << "Options:\n"
              << "\t-h,--help\t\t\tShow this help message\n"
              << "\t-w,--wordlist WORDLIST_FILE\tSpecify the input wordlist path\n"
              << "\t-d,--delimiter \" \"\tSpecify the delimiter for the words\n"
              << "\t--help\tShow this screen!\n"
              << "Version: 0.1\n"
              << "Author: Vavaldi [vavaldi@hashmob.net]\n\n"
              << std::endl;
}

std::vector<std::string> load_data(const std::string& input_file_location) {
    std::vector<std::string> output_dictionary;
    std::ifstream input_file(input_file_location);
    std::string line;
    while(getline(input_file, line)) {
        output_dictionary.push_back(std::move(line));
    }
    return output_dictionary;
}

// Join function to add delimiter
template <typename T>
std::string join(const T& v, const std::string& delim) {
    std::ostringstream s;
    for (const auto& i : v) {
        if (&i != &v[0]) {
            s << delim;
        }
        s << i;
    }
    return s.str();
}

// Loop through permutations recursively
void permute_all(std::vector<std::string>& buffer, size_t depth, std::vector<std::string>& output_buffer) {
    if(output_buffer.size() > 20000) {
        std::unique_lock<std::mutex> new_lock(output_lock); // Lock
        output_queue.push(output_buffer);
        new_lock.unlock(); // Unlock
        output_buffer.clear();
    }

    for(const auto& word : dictionary) {
        if (std::find(buffer.begin(), buffer.end(), word) != buffer.end()) continue;

        buffer.emplace_back(word);
        if(depth == 1) {
            output_buffer.emplace_back(join(buffer, delimiter));
        } else {
            permute_all(buffer, depth - 1, output_buffer);
        }
        buffer.pop_back();
    }
}

void permute_all_thread(size_t depth) {
    while(!input_queue.empty() || is_processing) {
        std::unique_lock<std::mutex> lock(input_lock);
        condition_var.wait(lock, [&] {
            return !(input_queue.empty() && is_processing);
        });
        if (input_queue.empty()) {
            lock.unlock();
            continue;
        }

        // Get word from queue to start it all off
        std::vector<std::vector<std::string>> queue_buffer = input_queue.front();
        input_queue.pop();
        lock.unlock();

        for(auto buffer : queue_buffer) {

            for (const auto &word: dictionary) {
                buffer.emplace_back(word);
                if (depth == 1) {
                    std::unique_lock<std::mutex> new_lock(output_lock); // Lock
                    output_queue.push({join(buffer, delimiter)});
                    new_lock.unlock(); // Unlock
                } else {
                    std::vector<std::string> output_buffer;
                    permute_all(buffer, depth - 1, output_buffer);

                    if(!output_buffer.empty()) {
                        std::unique_lock<std::mutex> new_lock(output_lock); // Lock
                        output_queue.push(output_buffer);
                        new_lock.unlock(); // Unlock
                    }
                }
                buffer.pop_back();
            }
        }
    }
}


void output_thread() {
    while(!(output_queue.empty() && is_fully_done)) {
        std::unique_lock<std::mutex> lock(output_lock);
        condition_var.wait(lock, [&] {
            return !(output_queue.empty() && !is_fully_done);
        });
        if (output_queue.empty()) {
            lock.unlock();
            continue;
        }

        // Get word from queue to start it all off
        std::vector<std::string> buffer = output_queue.front();
        output_queue.pop();
        lock.unlock();

        std::string s;
        s.reserve(10000000);
        for(const auto& item : buffer) {
            s.append(item + '\n');
        }
        lock.lock();
        std::cout << s;
        lock.unlock();
    }
}


int main(int argc, const char *argv[]) {
    if (argc < 2) {
        show_usage();
        return 1;
    }

    std::string input_wordlist;
    bool help{false};
    for (int i = 1; i < argc; ++i) {
        if (std::string(argv[i]) == "--wordlist" || std::string(argv[i]) == "-w") {
            if (i + 1 < argc && argv[i+1][0] != '-' && strlen(argv[i+1]) > 1 ) {
                input_wordlist = argv[i+1];
            } else {
                std::cerr << argv[i] << " option requires an argument." << std::endl;
                return -1;
            }
        }
        if (std::string(argv[i]) == "--delimiter" || std::string(argv[i]) == "-d") {
            if (i + 1 < argc && argv[i+1][0] != '-' && strlen(argv[i+1]) >= 1 ) {
                delimiter = argv[i+1];
            } else {
                std::cerr << argv[i] << " option requires an argument." << std::endl;
                return -1;
            }
        }
        if (std::string(argv[i]) == "--help" || std::string(argv[i]) == "-h") {
            help = true;
        }
    }

    if(help) {
        show_usage();
        return 0;
    }

    try {
        if (!std::filesystem::exists(input_wordlist)) {
            std::cerr << "Invalid Path" << std::endl;
            return 0;
        }
    } catch(...) {};

    dictionary = load_data(input_wordlist);
    std::thread output_thread_handle = std::thread(&output_thread);
    std::thread output_thread_handle2 = std::thread(&output_thread);
    std::thread output_thread_handle3 = std::thread(&output_thread);

    for(size_t length = 4; length <= dictionary.size(); length++) {
        for (size_t t_id = 0; t_id < std::thread::hardware_concurrency(); t_id++) {
            threads.emplace_back(std::thread(&permute_all_thread, length));
        }

        std::vector<std::vector<std::string>> input_buffer;
        for(const auto& word : dictionary) {
            while (input_queue.size() > 100) { // Limit queue size
                condition_var.notify_one();
                std::this_thread::sleep_for(std::chrono::milliseconds(20));
                std::cout << output_queue.size() << std::endl;
            }

            input_buffer.push_back({word});
            if(input_buffer.size() > 1000) {
                std::unique_lock<std::mutex> lock(input_lock); // Lock
                input_queue.push(input_buffer);
                lock.unlock();
                condition_var.notify_one();
                input_buffer.clear();
            }
        }

        if(!input_buffer.empty()) {
            std::unique_lock<std::mutex> lock(input_lock); // Lock
            input_queue.push(input_buffer);
            lock.unlock();
            condition_var.notify_one();
            input_buffer.clear();
        }
        // Empty out the queue
        // Empty out the queue
        // Empty out the queue
        is_processing = false;
        std::this_thread::sleep_for(std::chrono::milliseconds(50));
        while (!input_queue.empty()) {
            condition_var.notify_all();
            std::this_thread::sleep_for(std::chrono::milliseconds(10));
        }
        condition_var.notify_all();
        for (auto &thread: threads) {
            condition_var.notify_all();
            if (thread.joinable()) {
                thread.join();
            }
        }
        is_processing = true;
    }

    // Clean output thread
    is_fully_done = true;
    if(output_thread_handle.joinable()) {
        output_thread_handle.join();
    }
    if(output_thread_handle2.joinable()) {
        output_thread_handle.join();
    }
    if(output_thread_handle3.joinable()) {
        output_thread_handle.join();
    }

    return 0;
}
